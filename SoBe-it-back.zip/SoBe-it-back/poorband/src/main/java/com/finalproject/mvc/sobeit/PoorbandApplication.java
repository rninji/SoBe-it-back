package com.finalproject.mvc.sobeit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PoorbandApplication {

	public static void main(String[] args) {
		SpringApplication.run(PoorbandApplication.class, args);
	}

}
